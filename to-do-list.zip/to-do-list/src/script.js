const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

// Load tasks from localStorage when the page loads
window.onload = function () {
  const savedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
  savedTasks.forEach((task) => addTaskToDOM(task.text, task.completed));
};

// Add task function
addBtn.addEventListener("click", () => {
  const taskText = taskInput.value.trim();
  if (taskText !== "") {
    addTaskToDOM(taskText, false);
    saveTask(taskText, false);
    taskInput.value = "";
  }
});

// Function to add task to the DOM
function addTaskToDOM(taskText, completed) {
  const li = document.createElement("li");

  // Create the clickable bubble
  const bubble = document.createElement("span");
  bubble.classList.add("task-bubble");
  if (completed) {
    bubble.classList.add("completed");
  }
  bubble.title = "Click to mark complete/incomplete";

  // Task text
  const taskSpan = document.createElement("span");
  taskSpan.textContent = taskText;
  if (completed) {
    taskSpan.classList.add("completed");
  }

  // When bubble is clicked, toggle completed status
  bubble.addEventListener("click", () => {
    bubble.classList.toggle("completed");
    taskSpan.classList.toggle("completed");
    updateTaskStatus(taskText, bubble.classList.contains("completed"));
  });

  // Delete button
  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "Delete";
  deleteBtn.onclick = () => {
    taskList.removeChild(li);
    removeTask(taskText);
  };

  li.appendChild(bubble);
  li.appendChild(taskSpan);
  li.appendChild(deleteBtn);
  taskList.appendChild(li);
}

// Save task to localStorage
function saveTask(taskText, completed) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks.push({ text: taskText, completed: completed });
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Remove task from localStorage
function removeTask(taskText) {
  let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks = tasks.filter((t) => t.text !== taskText);
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Update task completed status in localStorage
function updateTaskStatus(taskText, completed) {
  let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks = tasks.map((t) => {
    if (t.text === taskText) {
      return { text: t.text, completed: completed };
    }
    return t;
  });
  localStorage.setItem("tasks", JSON.stringify(tasks));
}
