# To Do List

A Pen created on CodePen.

Original URL: [https://codepen.io/Alexis-Jones-the-styleful/pen/QwjqKKY](https://codepen.io/Alexis-Jones-the-styleful/pen/QwjqKKY).

This is a way you can put all your thoughts into one place. If you have several projects, or have several tasks to do on your computer, you can put them here. While it doesn't organize your tasks, you can see all of them. For example, if you have a video call with John, but you also have to finish working on a project, or new things get added to your tasks, this is a great way to write down everything that needs to get done. You can check it off when you're done, or even delete it. If you want to start fresh, delete everything and it will still work. Once you delete something, you can not undo it without putting back into the list.